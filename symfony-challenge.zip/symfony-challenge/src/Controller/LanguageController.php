<?php
/**
 * Created by PhpStorm.
 * User: michael
 * Date: 04/01/18
 * Time: 11:13
 */

namespace App\Controller;


use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class LanguageController extends Controller
{
    /**
     * @Route(
     *     "/",
     *     name="select_fr",
     *     host="{subdomain}.symfony-challenge.dev",
     *     defaults={"subdomain"="www"},
     *     requirements={"subdomain"="france|belgique|luxembourg|suisse"})
     *
     */

    public function selectFr()
    {
            return $this->render('index.html.twig', array(
                "_locale" => 'fr'
            ));
    }

    /**
     * @Route(
     *     "/",
     *     name="select_en",
     *     host="{subdomain}.symfony-challenge.dev",
     *     requirements={"subdomain"="www|united-kingdom|united-states|australia|new-zealand|ireland|canada"})
     *
     */

    public function selectEn()
    {
        return $this->render('index.html.twig', array(
            "_locale" => 'en'
        ));
    }

    /**
     * @Route(
     *     "/",
     *     name="select_de",
     *     host="{subdomain}.symfony-challenge.dev",
     *     requirements={"subdomain"="deutschland|schweiz|osterreich"})
     *
     */

    public function selectDe()
    {
        return $this->render('index.html.twig', array(
            "_locale" => 'de'
        ));
    }

    /**
     * @Route(
     *     "/",
     *     name="select_nl",
     *     host="{subdomain}.symfony-challenge.dev",
     *     requirements={"subdomain"="nederland|belgie"})
     *
     */

    public function selectNl()
    {
        return $this->render('index.html.twig', array(
            "_locale" => 'nl'
        ));
    }

}