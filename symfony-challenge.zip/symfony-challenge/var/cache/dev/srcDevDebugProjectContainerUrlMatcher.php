<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        $host = $context->getHost();

        if (preg_match('#^(?P<subdomain>france|belgique|luxembourg|suisse)\\.symfony\\-challenge\\.dev$#si', $host, $hostMatches)) {
            // select_fr
            if ('' === $trimmedPathinfo) {
                $ret = $this->mergeDefaults(array_replace($hostMatches, array('_route' => 'select_fr')), array (  'subdomain' => 'www',  '_controller' => 'App\\Controller\\LanguageController::selectFr',));
                if (substr($pathinfo, -1) !== '/') {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'select_fr'));
                }

                return $ret;
            }

        }

        if (preg_match('#^(?P<subdomain>www|united-kingdom|united-states|australia|new-zealand|ireland|canada)\\.symfony\\-challenge\\.dev$#si', $host, $hostMatches)) {
            // select_en
            if ('' === $trimmedPathinfo) {
                $ret = $this->mergeDefaults(array_replace($hostMatches, array('_route' => 'select_en')), array (  '_controller' => 'App\\Controller\\LanguageController::selectEn',));
                if (substr($pathinfo, -1) !== '/') {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'select_en'));
                }

                return $ret;
            }

        }

        if (preg_match('#^(?P<subdomain>deutschland|schweiz|osterreich)\\.symfony\\-challenge\\.dev$#si', $host, $hostMatches)) {
            // select_de
            if ('' === $trimmedPathinfo) {
                $ret = $this->mergeDefaults(array_replace($hostMatches, array('_route' => 'select_de')), array (  '_controller' => 'App\\Controller\\LanguageController::selectDe',));
                if (substr($pathinfo, -1) !== '/') {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'select_de'));
                }

                return $ret;
            }

        }

        if (preg_match('#^(?P<subdomain>nederland|belgie)\\.symfony\\-challenge\\.dev$#si', $host, $hostMatches)) {
            // select_nl
            if ('' === $trimmedPathinfo) {
                $ret = $this->mergeDefaults(array_replace($hostMatches, array('_route' => 'select_nl')), array (  '_controller' => 'App\\Controller\\LanguageController::selectNl',));
                if (substr($pathinfo, -1) !== '/') {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'select_nl'));
                }

                return $ret;
            }

        }

        // _twig_error_test
        if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
