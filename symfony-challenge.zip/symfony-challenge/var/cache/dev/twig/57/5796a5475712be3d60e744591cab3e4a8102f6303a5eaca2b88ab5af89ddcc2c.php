<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_d4ac3615a5bcb6fcfdd683d3f199214eb3152c74aac8345b46fbb8e6e30f4078 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_62fd5bed284d8e970129871cde8e4608cb34d8095b0f209603b806ebc5208f65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_62fd5bed284d8e970129871cde8e4608cb34d8095b0f209603b806ebc5208f65->enter($__internal_62fd5bed284d8e970129871cde8e4608cb34d8095b0f209603b806ebc5208f65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_62fd5bed284d8e970129871cde8e4608cb34d8095b0f209603b806ebc5208f65->leave($__internal_62fd5bed284d8e970129871cde8e4608cb34d8095b0f209603b806ebc5208f65_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/button_label.html.php");
    }
}
