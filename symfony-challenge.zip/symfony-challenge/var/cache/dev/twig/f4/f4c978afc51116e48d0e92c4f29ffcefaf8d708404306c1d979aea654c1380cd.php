<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_0c325bb6743e66603b40650e4c6e92d64fb006a4f7b27bd73f127e1445be5e63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2b6464572f2f5d439be22eede8d372c1fe92310a0364524914ddedaeaee025de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b6464572f2f5d439be22eede8d372c1fe92310a0364524914ddedaeaee025de->enter($__internal_2b6464572f2f5d439be22eede8d372c1fe92310a0364524914ddedaeaee025de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_2b6464572f2f5d439be22eede8d372c1fe92310a0364524914ddedaeaee025de->leave($__internal_2b6464572f2f5d439be22eede8d372c1fe92310a0364524914ddedaeaee025de_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/form_enctype.html.php");
    }
}
