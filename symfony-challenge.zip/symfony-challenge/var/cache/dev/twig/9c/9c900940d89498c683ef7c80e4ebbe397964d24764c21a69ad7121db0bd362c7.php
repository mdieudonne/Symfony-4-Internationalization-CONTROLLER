<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_69e46de275ce5a31240c70dc1e35693aaec26d393f9f3201d3327757294a1beb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab2759fe987fcd92a9b650a56c7be66b304a6704c12b26972c285427343e6ed4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab2759fe987fcd92a9b650a56c7be66b304a6704c12b26972c285427343e6ed4->enter($__internal_ab2759fe987fcd92a9b650a56c7be66b304a6704c12b26972c285427343e6ed4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_ab2759fe987fcd92a9b650a56c7be66b304a6704c12b26972c285427343e6ed4->leave($__internal_ab2759fe987fcd92a9b650a56c7be66b304a6704c12b26972c285427343e6ed4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/password_widget.html.php");
    }
}
