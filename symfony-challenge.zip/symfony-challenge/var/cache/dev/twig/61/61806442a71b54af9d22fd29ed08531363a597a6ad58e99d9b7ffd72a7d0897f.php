<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_6b9e6ce75d30fb731b6145fb55a29615a83ad700ac6811ac5e91771a5a61da5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6588efa8a3a7aec0b93fdd18ff1c545db9208b709b3ab6c24449f892bedff648 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6588efa8a3a7aec0b93fdd18ff1c545db9208b709b3ab6c24449f892bedff648->enter($__internal_6588efa8a3a7aec0b93fdd18ff1c545db9208b709b3ab6c24449f892bedff648_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_6588efa8a3a7aec0b93fdd18ff1c545db9208b709b3ab6c24449f892bedff648->leave($__internal_6588efa8a3a7aec0b93fdd18ff1c545db9208b709b3ab6c24449f892bedff648_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/form_rows.html.php");
    }
}
