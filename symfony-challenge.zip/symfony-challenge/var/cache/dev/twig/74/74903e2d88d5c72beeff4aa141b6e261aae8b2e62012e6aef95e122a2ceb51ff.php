<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_7138df11ff522d9b933c8619e2d742ab302f2e17c2981fd8b88539d962016460 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b26672a886ebf4923faa1ec76a54478dec1cece408a1efb9f911a3539775676d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b26672a886ebf4923faa1ec76a54478dec1cece408a1efb9f911a3539775676d->enter($__internal_b26672a886ebf4923faa1ec76a54478dec1cece408a1efb9f911a3539775676d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_b26672a886ebf4923faa1ec76a54478dec1cece408a1efb9f911a3539775676d->leave($__internal_b26672a886ebf4923faa1ec76a54478dec1cece408a1efb9f911a3539775676d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/twig-bundle/Resources/views/Exception/error.rdf.twig");
    }
}
