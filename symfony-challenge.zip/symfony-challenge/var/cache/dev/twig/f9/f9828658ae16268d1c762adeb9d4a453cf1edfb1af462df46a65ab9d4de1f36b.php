<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_e5be7be5d7177caa61e4d8794c6d35dff06f5280ea4c4e5230ae3036946887f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_96992c548f1d293deae54f124ed7643e1cb7313719c913fc21322c4188cbdee9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96992c548f1d293deae54f124ed7643e1cb7313719c913fc21322c4188cbdee9->enter($__internal_96992c548f1d293deae54f124ed7643e1cb7313719c913fc21322c4188cbdee9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_96992c548f1d293deae54f124ed7643e1cb7313719c913fc21322c4188cbdee9->leave($__internal_96992c548f1d293deae54f124ed7643e1cb7313719c913fc21322c4188cbdee9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/email_widget.html.php");
    }
}
