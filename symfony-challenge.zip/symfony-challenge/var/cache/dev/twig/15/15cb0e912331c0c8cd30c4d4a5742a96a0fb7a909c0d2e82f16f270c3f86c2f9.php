<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_69e9e227012265148d461aa15c849305aa74128e55cbc530eb245c19c0ecae65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_329debb231377f9637f011bdf90a563fc1bd518cc53bc999851837f93c4ba63d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_329debb231377f9637f011bdf90a563fc1bd518cc53bc999851837f93c4ba63d->enter($__internal_329debb231377f9637f011bdf90a563fc1bd518cc53bc999851837f93c4ba63d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_329debb231377f9637f011bdf90a563fc1bd518cc53bc999851837f93c4ba63d->leave($__internal_329debb231377f9637f011bdf90a563fc1bd518cc53bc999851837f93c4ba63d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/twig-bundle/Resources/views/Exception/error.atom.twig");
    }
}
