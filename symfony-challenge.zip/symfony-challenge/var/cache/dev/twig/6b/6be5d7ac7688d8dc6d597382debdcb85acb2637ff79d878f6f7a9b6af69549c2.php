<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_f375d0a8f89e3e6301423456467d1fb1ae05c05cd4b43439636f0753548157a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f4f1a3d7fea130236ee045ce317644d34d0304251b33ac281ba8690ff4519ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f4f1a3d7fea130236ee045ce317644d34d0304251b33ac281ba8690ff4519ae->enter($__internal_3f4f1a3d7fea130236ee045ce317644d34d0304251b33ac281ba8690ff4519ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_3f4f1a3d7fea130236ee045ce317644d34d0304251b33ac281ba8690ff4519ae->leave($__internal_3f4f1a3d7fea130236ee045ce317644d34d0304251b33ac281ba8690ff4519ae_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
