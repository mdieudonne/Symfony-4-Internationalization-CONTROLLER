<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_abe5f8669ba454c090fe378dfb7c69fcbddf369080f942c4ae9e7ced66d27837 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76ab54a09e301bb08d2ffa6b60ec4c72c00d0e3d866e930f9fe6def2d4bc046e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76ab54a09e301bb08d2ffa6b60ec4c72c00d0e3d866e930f9fe6def2d4bc046e->enter($__internal_76ab54a09e301bb08d2ffa6b60ec4c72c00d0e3d866e930f9fe6def2d4bc046e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_76ab54a09e301bb08d2ffa6b60ec4c72c00d0e3d866e930f9fe6def2d4bc046e->leave($__internal_76ab54a09e301bb08d2ffa6b60ec4c72c00d0e3d866e930f9fe6def2d4bc046e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/submit_widget.html.php");
    }
}
