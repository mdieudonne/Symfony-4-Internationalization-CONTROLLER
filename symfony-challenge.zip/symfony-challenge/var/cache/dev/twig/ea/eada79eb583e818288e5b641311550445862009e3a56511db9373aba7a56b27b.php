<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_ca4a3db2774973c20e4b2d907e933353debdcad1df4b649df3b17969cb4f7ee6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b287358a32945c029fe1d786fb2a6aa7b45c9fc45fc97071839ee60af7d9aa4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b287358a32945c029fe1d786fb2a6aa7b45c9fc45fc97071839ee60af7d9aa4b->enter($__internal_b287358a32945c029fe1d786fb2a6aa7b45c9fc45fc97071839ee60af7d9aa4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_b287358a32945c029fe1d786fb2a6aa7b45c9fc45fc97071839ee60af7d9aa4b->leave($__internal_b287358a32945c029fe1d786fb2a6aa7b45c9fc45fc97071839ee60af7d9aa4b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/form_row.html.php");
    }
}
