<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_730eedbf4237d35f0b9de90af6941886bdf006539830804e9300123c110fb212 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f43191aa2faba6a624da61bb41d584e5fc138baac3683dca2405d2b085979bce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f43191aa2faba6a624da61bb41d584e5fc138baac3683dca2405d2b085979bce->enter($__internal_f43191aa2faba6a624da61bb41d584e5fc138baac3683dca2405d2b085979bce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_f43191aa2faba6a624da61bb41d584e5fc138baac3683dca2405d2b085979bce->leave($__internal_f43191aa2faba6a624da61bb41d584e5fc138baac3683dca2405d2b085979bce_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/twig-bundle/Resources/views/Exception/exception.rdf.twig");
    }
}
