<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_acd61441eca92a097523940fe664a964f4ab3383ffd5cd66801d79a1d66f79aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdd2f0a3d004c7b92829e6edb5a2235b9f59304ba5660d7a836f6a8315231ae6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdd2f0a3d004c7b92829e6edb5a2235b9f59304ba5660d7a836f6a8315231ae6->enter($__internal_fdd2f0a3d004c7b92829e6edb5a2235b9f59304ba5660d7a836f6a8315231ae6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_fdd2f0a3d004c7b92829e6edb5a2235b9f59304ba5660d7a836f6a8315231ae6->leave($__internal_fdd2f0a3d004c7b92829e6edb5a2235b9f59304ba5660d7a836f6a8315231ae6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/twig-bundle/Resources/views/Exception/exception.atom.twig");
    }
}
