<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_9203473fb4c2978f269daa40be9bcd0326c623d96545ddf3cfe4b063c616e7d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1aca01d1c21b9c259c3b16f6eda680b0038700d6e6cb91fde7387e018b8f0723 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1aca01d1c21b9c259c3b16f6eda680b0038700d6e6cb91fde7387e018b8f0723->enter($__internal_1aca01d1c21b9c259c3b16f6eda680b0038700d6e6cb91fde7387e018b8f0723_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_1aca01d1c21b9c259c3b16f6eda680b0038700d6e6cb91fde7387e018b8f0723->leave($__internal_1aca01d1c21b9c259c3b16f6eda680b0038700d6e6cb91fde7387e018b8f0723_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/form_errors.html.php");
    }
}
