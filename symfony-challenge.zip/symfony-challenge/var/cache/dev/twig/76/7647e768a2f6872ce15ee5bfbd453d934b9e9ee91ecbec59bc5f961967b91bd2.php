<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_0f8728e005096e760545b11164d934a8a1b66bc61056af49b87d7ec5a9f0ec4f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b94ccaaf516ede8b4b234a7150b3b31b10ad69664d227edfaa109e51536b2968 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b94ccaaf516ede8b4b234a7150b3b31b10ad69664d227edfaa109e51536b2968->enter($__internal_b94ccaaf516ede8b4b234a7150b3b31b10ad69664d227edfaa109e51536b2968_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_b94ccaaf516ede8b4b234a7150b3b31b10ad69664d227edfaa109e51536b2968->leave($__internal_b94ccaaf516ede8b4b234a7150b3b31b10ad69664d227edfaa109e51536b2968_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/form_widget.html.php");
    }
}
