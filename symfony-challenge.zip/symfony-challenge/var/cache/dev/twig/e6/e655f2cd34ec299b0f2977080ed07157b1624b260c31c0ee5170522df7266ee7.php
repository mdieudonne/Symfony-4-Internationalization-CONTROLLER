<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_edb83ae59e0e2c0b942efc3e83ba96cefd0f34e03cb6adf12268c761f2d9c867 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c85a2f4500b53242930763fcebf29c68cd0263ffc0737d6dea3c1ae2d9db3221 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c85a2f4500b53242930763fcebf29c68cd0263ffc0737d6dea3c1ae2d9db3221->enter($__internal_c85a2f4500b53242930763fcebf29c68cd0263ffc0737d6dea3c1ae2d9db3221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_c85a2f4500b53242930763fcebf29c68cd0263ffc0737d6dea3c1ae2d9db3221->leave($__internal_c85a2f4500b53242930763fcebf29c68cd0263ffc0737d6dea3c1ae2d9db3221_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/search_widget.html.php");
    }
}
