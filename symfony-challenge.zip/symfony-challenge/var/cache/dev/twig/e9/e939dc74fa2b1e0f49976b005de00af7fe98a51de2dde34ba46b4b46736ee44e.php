<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_33c1b9dd877eb8850f67244d656c9751cbf520bb43de318256bee6ff0599755f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_278ea97079433e0b409c23fea7df50c66e9d7460616ab6676d73abcc61863b3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_278ea97079433e0b409c23fea7df50c66e9d7460616ab6676d73abcc61863b3c->enter($__internal_278ea97079433e0b409c23fea7df50c66e9d7460616ab6676d73abcc61863b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_278ea97079433e0b409c23fea7df50c66e9d7460616ab6676d73abcc61863b3c->leave($__internal_278ea97079433e0b409c23fea7df50c66e9d7460616ab6676d73abcc61863b3c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/collection_widget.html.php");
    }
}
