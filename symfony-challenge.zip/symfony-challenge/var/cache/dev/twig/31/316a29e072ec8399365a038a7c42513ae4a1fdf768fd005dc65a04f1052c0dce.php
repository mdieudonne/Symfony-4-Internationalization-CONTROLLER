<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_892e07396a51930aff0b81b0367d2d6e54ea31360961db395b6b1d7bb15031e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6ccc31fabbeff4d30457f4539c48db6e0c5b9f1946c65c929c1bdc7a98bd8c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6ccc31fabbeff4d30457f4539c48db6e0c5b9f1946c65c929c1bdc7a98bd8c7->enter($__internal_f6ccc31fabbeff4d30457f4539c48db6e0c5b9f1946c65c929c1bdc7a98bd8c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_f6ccc31fabbeff4d30457f4539c48db6e0c5b9f1946c65c929c1bdc7a98bd8c7->leave($__internal_f6ccc31fabbeff4d30457f4539c48db6e0c5b9f1946c65c929c1bdc7a98bd8c7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
", "@Framework/Form/range_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/range_widget.html.php");
    }
}
