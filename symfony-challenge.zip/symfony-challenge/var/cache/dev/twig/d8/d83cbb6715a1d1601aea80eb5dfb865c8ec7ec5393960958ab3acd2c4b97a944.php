<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_f4565fe60a57de899b0dd7ccdf867b3385b5a37fcd3253ccd4be5f1b3422a166 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f187e474728a389ecafbf25c538d2572934f44dc6e9a72d743e5e442e1b4f2e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f187e474728a389ecafbf25c538d2572934f44dc6e9a72d743e5e442e1b4f2e->enter($__internal_6f187e474728a389ecafbf25c538d2572934f44dc6e9a72d743e5e442e1b4f2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_6f187e474728a389ecafbf25c538d2572934f44dc6e9a72d743e5e442e1b4f2e->leave($__internal_6f187e474728a389ecafbf25c538d2572934f44dc6e9a72d743e5e442e1b4f2e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/hidden_row.html.php");
    }
}
