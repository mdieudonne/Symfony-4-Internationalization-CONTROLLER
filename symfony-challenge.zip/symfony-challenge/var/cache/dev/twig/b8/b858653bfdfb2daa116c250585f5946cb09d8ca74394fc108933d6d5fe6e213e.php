<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_943a0f3eff73e6f6972ba30eaf185787170d3e082b8993d36afdd28c53b2afe3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa65cffe13cb84f103aa8edde6a41f7af4bfe5e4240c323de480b876950a60a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa65cffe13cb84f103aa8edde6a41f7af4bfe5e4240c323de480b876950a60a9->enter($__internal_aa65cffe13cb84f103aa8edde6a41f7af4bfe5e4240c323de480b876950a60a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_aa65cffe13cb84f103aa8edde6a41f7af4bfe5e4240c323de480b876950a60a9->leave($__internal_aa65cffe13cb84f103aa8edde6a41f7af4bfe5e4240c323de480b876950a60a9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/radio_widget.html.php");
    }
}
