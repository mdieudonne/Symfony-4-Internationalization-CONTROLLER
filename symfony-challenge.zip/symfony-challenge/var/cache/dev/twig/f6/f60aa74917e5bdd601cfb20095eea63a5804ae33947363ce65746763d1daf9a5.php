<?php

/* index.html.twig */
class __TwigTemplate_ee3592ce9f1b2f210421862d5ed9450d4e4e6d453f161a2c2f3053d158d179c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "index.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1022833cb00f8dfe5b9656b79ab797c6b51255e4569282a526b0cc3e6aef338f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1022833cb00f8dfe5b9656b79ab797c6b51255e4569282a526b0cc3e6aef338f->enter($__internal_1022833cb00f8dfe5b9656b79ab797c6b51255e4569282a526b0cc3e6aef338f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1022833cb00f8dfe5b9656b79ab797c6b51255e4569282a526b0cc3e6aef338f->leave($__internal_1022833cb00f8dfe5b9656b79ab797c6b51255e4569282a526b0cc3e6aef338f_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{%  extends 'base.html.twig' %}

", "index.html.twig", "/media/simplon/virtual-hosts/symfony-challenge/templates/index.html.twig");
    }
}
