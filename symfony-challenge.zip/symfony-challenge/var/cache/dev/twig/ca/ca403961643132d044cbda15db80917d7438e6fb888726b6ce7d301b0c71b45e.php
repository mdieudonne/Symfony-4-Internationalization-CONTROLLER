<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_44f27fa672f439cd526a2ba0943737fe7bf091c65de097d1f04b15ecea09d50f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8083b53b542154bc68115f3be4887a734d2c62605aa38c1fc5d0cdc420b8310 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8083b53b542154bc68115f3be4887a734d2c62605aa38c1fc5d0cdc420b8310->enter($__internal_d8083b53b542154bc68115f3be4887a734d2c62605aa38c1fc5d0cdc420b8310_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })())));
        echo "
*/
";
        
        $__internal_d8083b53b542154bc68115f3be4887a734d2c62605aa38c1fc5d0cdc420b8310->leave($__internal_d8083b53b542154bc68115f3be4887a734d2c62605aa38c1fc5d0cdc420b8310_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/twig-bundle/Resources/views/Exception/exception.js.twig");
    }
}
