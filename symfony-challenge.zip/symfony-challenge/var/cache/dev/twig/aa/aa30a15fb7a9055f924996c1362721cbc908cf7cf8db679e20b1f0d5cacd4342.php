<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_fd782cf226d616b42b99b2b54b4f26d102f4ffe169f10e120b98e075f880e911 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f6fbd06746148478396a900d0f2568d4dd05889c7f72a57073c0ebc1cd59e9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f6fbd06746148478396a900d0f2568d4dd05889c7f72a57073c0ebc1cd59e9e->enter($__internal_0f6fbd06746148478396a900d0f2568d4dd05889c7f72a57073c0ebc1cd59e9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_0f6fbd06746148478396a900d0f2568d4dd05889c7f72a57073c0ebc1cd59e9e->leave($__internal_0f6fbd06746148478396a900d0f2568d4dd05889c7f72a57073c0ebc1cd59e9e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/button_row.html.php");
    }
}
