<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_42d9711473b3cbbbe8b6bff85822dabbf6358a0c5b0114ba0264abcfd4a228b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19f4d6cdc25b87d4ebb542786b7694c5edf1355b22423bdab352f557481a5bf5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19f4d6cdc25b87d4ebb542786b7694c5edf1355b22423bdab352f557481a5bf5->enter($__internal_19f4d6cdc25b87d4ebb542786b7694c5edf1355b22423bdab352f557481a5bf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_19f4d6cdc25b87d4ebb542786b7694c5edf1355b22423bdab352f557481a5bf5->leave($__internal_19f4d6cdc25b87d4ebb542786b7694c5edf1355b22423bdab352f557481a5bf5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/form.html.php");
    }
}
