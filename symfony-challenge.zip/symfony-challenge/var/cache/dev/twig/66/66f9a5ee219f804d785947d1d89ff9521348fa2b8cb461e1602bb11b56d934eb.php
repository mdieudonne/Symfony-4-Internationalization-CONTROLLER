<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_d3e576470714dbe2eda63023787acda1e84fbc13b279921901d2bce327ee3e9b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c01d39ee4213265180adbf782a20d0535538b289471df4d210875ae57c0551f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c01d39ee4213265180adbf782a20d0535538b289471df4d210875ae57c0551f->enter($__internal_9c01d39ee4213265180adbf782a20d0535538b289471df4d210875ae57c0551f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_9c01d39ee4213265180adbf782a20d0535538b289471df4d210875ae57c0551f->leave($__internal_9c01d39ee4213265180adbf782a20d0535538b289471df4d210875ae57c0551f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/widget_container_attributes.html.php");
    }
}
