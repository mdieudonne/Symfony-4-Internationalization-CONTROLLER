<?php

/* base.html.twig */
class __TwigTemplate_9b3dc1948127c1bc9eeb43b0120fd36d8f5690ebed5213a05dd01700d0e32157 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_582e6d1a312b492fe347524b4f81c19f1863e2a2fa77c407d3dba4cd10d5179e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_582e6d1a312b492fe347524b4f81c19f1863e2a2fa77c407d3dba4cd10d5179e->enter($__internal_582e6d1a312b492fe347524b4f81c19f1863e2a2fa77c407d3dba4cd10d5179e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\">
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "</head>
<body>
";
        // line 9
        $this->displayBlock('body', $context, $blocks);
        // line 50
        $this->displayBlock('javascripts', $context, $blocks);
        // line 51
        echo "
</body>
</html>
";
        
        $__internal_582e6d1a312b492fe347524b4f81c19f1863e2a2fa77c407d3dba4cd10d5179e->leave($__internal_582e6d1a312b492fe347524b4f81c19f1863e2a2fa77c407d3dba4cd10d5179e_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_d92c76ce16a20d73f8a18c290a92d691b14121f9d737cd9979afda3bbfdc921f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d92c76ce16a20d73f8a18c290a92d691b14121f9d737cd9979afda3bbfdc921f->enter($__internal_d92c76ce16a20d73f8a18c290a92d691b14121f9d737cd9979afda3bbfdc921f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_d92c76ce16a20d73f8a18c290a92d691b14121f9d737cd9979afda3bbfdc921f->leave($__internal_d92c76ce16a20d73f8a18c290a92d691b14121f9d737cd9979afda3bbfdc921f_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a1ca5706697c14116b9ef015525c277ae92e0e8f3dc18e6bfe4b44e753916f52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1ca5706697c14116b9ef015525c277ae92e0e8f3dc18e6bfe4b44e753916f52->enter($__internal_a1ca5706697c14116b9ef015525c277ae92e0e8f3dc18e6bfe4b44e753916f52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        echo "<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\">";
        
        $__internal_a1ca5706697c14116b9ef015525c277ae92e0e8f3dc18e6bfe4b44e753916f52->leave($__internal_a1ca5706697c14116b9ef015525c277ae92e0e8f3dc18e6bfe4b44e753916f52_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_2a1d16f2269a6979270f924a3cd25aee9527edbe166e1ab04f1e85711e2bb8ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a1d16f2269a6979270f924a3cd25aee9527edbe166e1ab04f1e85711e2bb8ad->enter($__internal_2a1d16f2269a6979270f924a3cd25aee9527edbe166e1ab04f1e85711e2bb8ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
    <div class=\"ban\">
        <h1>";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("messages.goodmorning", array(), "messages", (isset($context["_locale"]) || array_key_exists("_locale", $context) ? $context["_locale"] : (function () { throw new Twig_Error_Runtime('Variable "_locale" does not exist.', 12, $this->getSourceContext()); })()));
        echo "</h1>
    </div>

    <a href=\"http://www.symfony-challenge.dev\">International</a>

    <h2>Francais</h2>
    <ul>
        <li><a href=\"http://france.symfony-challenge.dev\">fr-FR</a></li>
        <li><a href=\"http://belgique.symfony-challenge.dev\">fr-BE</a></li>
        <li><a href=\"http://luxembourg.symfony-challenge.dev\">fr-LU</a></li>
        <li><a href=\"http://suisse.symfony-challenge.dev\">fr-CH</a></li>
    </ul>

    <h2>English</h2>
    <ul>
        <li><a href=\"http://united-kingdom.symfony-challenge.dev\">en-GB</a></li>
        <li><a href=\"http://australia.symfony-challenge.dev\">en-AU</a></li>
        <li><a href=\"http://united-states.symfony-challenge.dev\">en-US</a></li>
        <li><a href=\"http://new-zealand.symfony-challenge.dev\">en-NZ</a></li>
        <li><a href=\"http://ireland.symfony-challenge.dev\">en-IE</a></li>
        <li><a href=\"http://canada.symfony-challenge.dev\">en-CA</a></li>
    </ul>

    <h2>Deutsch</h2>
    <ul>
        <li><a href=\"http://deutschland.symfony-challenge.dev\">de-DE</a></li>
        <li><a href=\"http://schweiz.symfony-challenge.dev\">de-CH</a></li>
        <li><a href=\"http://osterreich.symfony-challenge.dev\">de-AT</a></li>

    </ul>

    <h2>Nederlands</h2>
    <ul>
        <li><a href=\"http://nederland.symfony-challenge.dev\">nl-NL</a></li>
        <li><a href=\"http://belgie.symfony-challenge.dev\">nl-BE</a></li>
    </ul>

";
        
        $__internal_2a1d16f2269a6979270f924a3cd25aee9527edbe166e1ab04f1e85711e2bb8ad->leave($__internal_2a1d16f2269a6979270f924a3cd25aee9527edbe166e1ab04f1e85711e2bb8ad_prof);

    }

    // line 50
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7c1824664c2daa6a11d784165568f901b47a41575b40fd75db7687fecf41b47f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c1824664c2daa6a11d784165568f901b47a41575b40fd75db7687fecf41b47f->enter($__internal_7c1824664c2daa6a11d784165568f901b47a41575b40fd75db7687fecf41b47f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_7c1824664c2daa6a11d784165568f901b47a41575b40fd75db7687fecf41b47f->leave($__internal_7c1824664c2daa6a11d784165568f901b47a41575b40fd75db7687fecf41b47f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  135 => 50,  90 => 12,  86 => 10,  80 => 9,  68 => 6,  56 => 5,  46 => 51,  44 => 50,  42 => 9,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\">
    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\">{% endblock %}
</head>
<body>
{% block body %}

    <div class=\"ban\">
        <h1>{% trans from \"messages\" into ( _locale ) %}messages.goodmorning{% endtrans %}</h1>
    </div>

    <a href=\"http://www.symfony-challenge.dev\">International</a>

    <h2>Francais</h2>
    <ul>
        <li><a href=\"http://france.symfony-challenge.dev\">fr-FR</a></li>
        <li><a href=\"http://belgique.symfony-challenge.dev\">fr-BE</a></li>
        <li><a href=\"http://luxembourg.symfony-challenge.dev\">fr-LU</a></li>
        <li><a href=\"http://suisse.symfony-challenge.dev\">fr-CH</a></li>
    </ul>

    <h2>English</h2>
    <ul>
        <li><a href=\"http://united-kingdom.symfony-challenge.dev\">en-GB</a></li>
        <li><a href=\"http://australia.symfony-challenge.dev\">en-AU</a></li>
        <li><a href=\"http://united-states.symfony-challenge.dev\">en-US</a></li>
        <li><a href=\"http://new-zealand.symfony-challenge.dev\">en-NZ</a></li>
        <li><a href=\"http://ireland.symfony-challenge.dev\">en-IE</a></li>
        <li><a href=\"http://canada.symfony-challenge.dev\">en-CA</a></li>
    </ul>

    <h2>Deutsch</h2>
    <ul>
        <li><a href=\"http://deutschland.symfony-challenge.dev\">de-DE</a></li>
        <li><a href=\"http://schweiz.symfony-challenge.dev\">de-CH</a></li>
        <li><a href=\"http://osterreich.symfony-challenge.dev\">de-AT</a></li>

    </ul>

    <h2>Nederlands</h2>
    <ul>
        <li><a href=\"http://nederland.symfony-challenge.dev\">nl-NL</a></li>
        <li><a href=\"http://belgie.symfony-challenge.dev\">nl-BE</a></li>
    </ul>

{% endblock %}
{% block javascripts %}{% endblock %}

</body>
</html>
", "base.html.twig", "/media/simplon/virtual-hosts/symfony-challenge/templates/base.html.twig");
    }
}
