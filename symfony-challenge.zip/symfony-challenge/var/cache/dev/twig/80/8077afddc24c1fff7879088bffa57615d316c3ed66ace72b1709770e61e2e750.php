<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_013b87f0cca330553ce574ceb8fe889981d04dd0b23a44816a7340bb069ca002 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0abfaa44b607730bac73831fafbe7a2a1911d0974fdb461fc06a404be195c782 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0abfaa44b607730bac73831fafbe7a2a1911d0974fdb461fc06a404be195c782->enter($__internal_0abfaa44b607730bac73831fafbe7a2a1911d0974fdb461fc06a404be195c782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_0abfaa44b607730bac73831fafbe7a2a1911d0974fdb461fc06a404be195c782->leave($__internal_0abfaa44b607730bac73831fafbe7a2a1911d0974fdb461fc06a404be195c782_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/media/simplon/virtual-hosts/symfony-challenge/vendor/symfony/framework-bundle/Resources/views/Form/choice_options.html.php");
    }
}
